
execute as @s at @s run particle dust_color_transition{from_color:[0.078,0.663,1.000],to_color:[0.000,0.835,1.000],scale:2.25} ^ ^1 ^1.1 0.21212 0.21212 0.21212 0.06 15 normal
execute as @s at @s run particle dust_color_transition{from_color:[0.000,0.835,1.000],to_color:[0.239,1.000,1.000],scale:2.5} ^ ^1 ^2 0.25 0.25 0.25 0.06 17 normal
execute as @s at @s run particle dust_color_transition{from_color:[0.239,1.000,1.000],to_color:[0.580,0.957,1.000],scale:3} ^ ^1 ^3 0.22 0.22 0.22 0.06 20 normal
execute as @s at @s run particle dust_color_transition{from_color:[0.580,0.957,1.000],to_color:[0.741,0.984,1.000],scale:3.5} ^ ^1 ^4 0.35 0.35 0.35 0.06 27 normal
execute as @s at @s run particle dust_color_transition{from_color:[0.741,0.984,1.000],to_color:[0.788,1.000,0.973],scale:4} ^ ^1 ^5 0.42 0.42 0.42 0.06 35 normal

#execute as @s at @s run particle dust_color_transition{from_color:[0.788,1.000,0.973],to_color:[0.741,0.984,1.000],scale:2.25} ^ ^1 ^1.1 0.21212 0.21212 0.21212 0.06 15 normal
#execute as @s at @s run particle dust_color_transition{from_color:[0.741,0.984,1.000],to_color:[0.580,0.957,1.000],scale:2.5} ^ ^1 ^2 0.25 0.25 0.25 0.06 17 normal
#execute as @s at @s run particle dust_color_transition{from_color:[0.580,0.957,1.000],to_color:[0.239,1.000,1.000],scale:3} ^ ^1 ^3 0.22 0.22 0.22 0.06 20 normal
#execute as @s at @s run particle dust_color_transition{from_color:[0.239,1.000,1.000],to_color:[0.000,0.835,1.000],scale:3.5} ^ ^1 ^4 0.35 0.35 0.35 0.06 27 normal
#execute as @s at @s run particle dust_color_transition{from_color:[0.000,0.835,1.000],to_color:[0.078,0.663,1.000],scale:4} ^ ^1 ^5 0.42 0.42 0.42 0.06 35 normal
execute as @s at @s run summon armor_stand ^ ^1 ^1 {NoGravity:1b,Small:1b,Invisible:1b,Tags:["freezethrower"]}
execute as @s at @s run summon armor_stand ^ ^1 ^2 {NoGravity:1b,Small:1b,Invisible:1b,Tags:["freezethrower"]}
execute as @s at @s run summon armor_stand ^ ^1 ^3 {NoGravity:1b,Small:1b,Invisible:1b,Tags:["freezethrower"]}
execute as @s at @s run summon armor_stand ^ ^1 ^4 {NoGravity:1b,Small:1b,Invisible:1b,Tags:["freezethrower"]}
execute as @s at @s run summon armor_stand ^ ^1 ^5 {NoGravity:1b,Small:1b,Invisible:1b,Tags:["freezethrower"]}
execute as @s at @s run execute as @e[type=armor_stand,distance=0..5,tag=freezethrower] at @e[type=armor_stand,distance=0..5,tag=freezethrower] run execute as @e[distance=0..1.2] at @s run damage @s 3.5 minecraft:freeze
execute as @s at @s run execute as @e[type=armor_stand,distance=0..5,tag=freezethrower] at @e[type=armor_stand,distance=0..5,tag=freezethrower] run effect give @e[distance=0..1.2] slowness 3 1 true
advancement revoke @s only sub_shotgun:freezethrower
kill @e[type=armor_stand,tag=freezethrower]