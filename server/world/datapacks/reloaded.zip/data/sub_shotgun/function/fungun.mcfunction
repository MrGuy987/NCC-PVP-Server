execute at @n[type=!#minecraft:impact_projectiles] run summon fireball ^ ^0.6 ^1 {Tags:["shotgun"]}
data modify entity @n[type=minecraft:fireball,tag=shotgun] Motion set from entity @s Motion
data modify entity @n[type=minecraft:fireball,tag=shotgun] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon fireball ^ ^-0.6 ^1 {Tags:["shotgun1"]}
data modify entity @n[type=minecraft:fireball,tag=shotgun1] Motion set from entity @s Motion
data modify entity @n[type=minecraft:fireball,tag=shotgun1] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon fireball ^0.6 ^0.3 ^1 {Tags:["shotgun2"]}
data modify entity @n[type=minecraft:fireball,tag=shotgun2] Motion set from entity @s Motion
data modify entity @n[type=minecraft:fireball,tag=shotgun2] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon fireball ^-0.6 ^0.3 ^1 {Tags:["shotgun3"]}
data modify entity @n[type=minecraft:fireball,tag=shotgun3] Motion set from entity @s Motion
data modify entity @n[type=minecraft:fireball,tag=shotgun3] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon fireball ^0.6 ^-0.3 ^1 {Tags:["shotgun4"]}
data modify entity @n[type=minecraft:fireball,tag=shotgun4] Motion set from entity @s Motion
data modify entity @n[type=minecraft:fireball,tag=shotgun4] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon fireball ^-0.6 ^-0.3 ^1 {Tags:["shotgun5"]}
data modify entity @n[type=minecraft:fireball,tag=shotgun5] Motion set from entity @s Motion
data modify entity @n[type=minecraft:fireball,tag=shotgun5] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon fireball ^ ^ ^1 {Tags:["shotgun6"]}
data modify entity @n[type=minecraft:fireball,tag=shotgun6] Motion set from entity @s Motion
data modify entity @n[type=minecraft:fireball,tag=shotgun6] Owner set from entity @s Owner
kill @s

