scoreboard players add @e charge_cooldown 1
scoreboard players add @e impulse_orb_cooldown 1