execute at @s run particle glow_squid_ink ~ ~1 ~ 0.3 0.3 0.3 0.4 70 normal
kill @s