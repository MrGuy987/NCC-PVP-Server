playsound minecraft:entity.firework_rocket.large_blast master @a[distance=0..15] ~ ~ ~ 3 1.2
summon firework_rocket ~ ~ ~ {LifeTime:60,ShotAtAngle:1b,Tags:["launcher"],FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_trail:true,colors:[I;16711680,16777215,6911],fade_colors:[I;16756141,16777215,11839743]},{shape:"star",has_twinkle:true,colors:[I;16711680,16777215,6911],fade_colors:[I;16756141,16777215,11839743]}]}}}}
data modify entity @n[type=minecraft:firework_rocket,tag=launcher] Motion set from entity @s Motion
data modify entity @n[type=minecraft:firework_rocket,tag=launcher] Owner set from entity @s Owner
kill @s

