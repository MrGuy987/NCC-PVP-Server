scoreboard players set @s charge_active 12
scoreboard players set @s charge_cooldown -12
execute at @s run particle gust_emitter_small ~ ~1 ~ 0 0 0 0 0 normal