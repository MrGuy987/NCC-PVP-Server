scoreboard players set @n[type=!#minecraft:impact_projectiles] sub_recoil 1
playsound minecraft:entity.generic.explode master @a[distance=0..15] ~ ~ ~ 1 2
execute at @n[type=!#minecraft:impact_projectiles] run summon small_fireball ^ ^0.6 ^1 {Tags:["shotgun"]}
data modify entity @n[type=minecraft:small_fireball,tag=shotgun] Motion set from entity @s Motion
data modify entity @n[type=minecraft:small_fireball,tag=shotgun] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon small_fireball ^ ^-0.6 ^1 {Tags:["shotgun1"]}
data modify entity @n[type=minecraft:small_fireball,tag=shotgun1] Motion set from entity @s Motion
data modify entity @n[type=minecraft:small_fireball,tag=shotgun1] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon small_fireball ^0.6 ^0.3 ^1 {Tags:["shotgun2"]}
data modify entity @n[type=minecraft:small_fireball,tag=shotgun2] Motion set from entity @s Motion
data modify entity @n[type=minecraft:small_fireball,tag=shotgun2] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon small_fireball ^-0.6 ^0.3 ^1 {Tags:["shotgun3"]}
data modify entity @n[type=minecraft:small_fireball,tag=shotgun3] Motion set from entity @s Motion
data modify entity @n[type=minecraft:small_fireball,tag=shotgun3] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon small_fireball ^0.6 ^-0.3 ^1 {Tags:["shotgun4"]}
data modify entity @n[type=minecraft:small_fireball,tag=shotgun4] Motion set from entity @s Motion
data modify entity @n[type=minecraft:small_fireball,tag=shotgun4] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon small_fireball ^-0.6 ^-0.3 ^1 {Tags:["shotgun5"]}
data modify entity @n[type=minecraft:small_fireball,tag=shotgun5] Motion set from entity @s Motion
data modify entity @n[type=minecraft:small_fireball,tag=shotgun5] Owner set from entity @s Owner
execute at @n[type=!#minecraft:impact_projectiles] run summon small_fireball ^ ^ ^1 {Tags:["shotgun6"]}
data modify entity @n[type=minecraft:small_fireball,tag=shotgun6] Motion set from entity @s Motion
data modify entity @n[type=minecraft:small_fireball,tag=shotgun6] Owner set from entity @s Owner
kill @s

