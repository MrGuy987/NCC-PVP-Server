scoreboard players set @s sub_airjump 0
execute at @s run playsound minecraft:entity.wind_charge.wind_burst master @a[distance=0..7] ~ ~ ~ 1 0.55
execute at @s run particle minecraft:gust_emitter_small ~ ~ ~ 0.2 0.2 0.2 0.1 2 normal