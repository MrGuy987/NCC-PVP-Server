scoreboard objectives add sub_recoil dummy
scoreboard objectives add sub_airjump dummy
scoreboard objectives add charge_active dummy
scoreboard objectives add charge_cooldown dummy
scoreboard objectives add impulse_orb_cooldown dummy