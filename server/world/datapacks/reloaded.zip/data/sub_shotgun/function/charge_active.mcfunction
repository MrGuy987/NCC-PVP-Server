scoreboard players remove @s charge_active 1
execute at @s run particle dust_color_transition{from_color:[0.000,0.635,1.000],to_color:[0.020,0.380,1.000],scale:4} ~ ~1 ~ 0 0 0 0 5 normal
execute at @s run damage @n[distance=0.1..1.5] 8 minecraft:player_attack by @s