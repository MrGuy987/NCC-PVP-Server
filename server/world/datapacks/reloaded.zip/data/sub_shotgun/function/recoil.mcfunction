scoreboard players set @s sub_recoil 0
execute at @s run particle minecraft:large_smoke ^ ^ ^1 0.3 0.3 0.3 0.18 80 normal