# Copper
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:copper"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:copper_ingot run return run \
function extratrims:change_trim_material/final {material:"minecraft:copper", item:"minecraft:copper_ingot"}

# Iron
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:iron"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:iron_ingot run return run \
function extratrims:change_trim_material/final {material:"minecraft:iron", item:"minecraft:iron_ingot"}

# Gold
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:gold"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:gold_ingot run return run \
function extratrims:change_trim_material/final {material:"minecraft:gold", item:"minecraft:gold_ingot"}

# Lapis
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:lapis"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:lapis_lazuli run return run \
function extratrims:change_trim_material/final {material:"minecraft:lapis", item:"minecraft:lapis_lazuli"}

# Redstone
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:redstone"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:redstone run return run \
function extratrims:change_trim_material/final {material:"minecraft:redstone", item:"minecraft:redstone"}

# Amethyst
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:amethyst"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:amethyst_shard run return run \
function extratrims:change_trim_material/final {material:"minecraft:amethyst", item:"minecraft:amethyst_shard"}

# Emerald
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:emerald"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:emerald run return run \
function extratrims:change_trim_material/final {material:"minecraft:emerald", item:"minecraft:emerald"}

# Diamond
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:diamond"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:diamond run return run \
function extratrims:change_trim_material/final {material:"minecraft:diamond", item:"minecraft:diamond"}

# Quartz
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:quartz"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:quartz run return run \
function extratrims:change_trim_material/final {material:"minecraft:quartz", item:"minecraft:quartz"}

# Netherite
execute unless items entity @s container.0 *[minecraft:trim~{material:"minecraft:netherite"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:netherite_ingot run return run \
function extratrims:change_trim_material/final {material:"minecraft:netherite", item:"minecraft:netherite_ingot"}

# Armadillo
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:armadillo"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:armadillo_scute run return run \
function extratrims:change_trim_material/final {material:"extratrims:armadillo", item:"minecraft:armadillo_scute"}

# Blaze
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:blaze"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:blaze_rod run return run \
function extratrims:change_trim_material/final {material:"extratrims:blaze", item:"minecraft:blaze_rod"}

# Bone
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:bone"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:bone run return run \
function extratrims:change_trim_material/final {material:"extratrims:bone", item:"minecraft:bone"}

# Breeze
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:breeze"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:breeze_rod run return run \
function extratrims:change_trim_material/final {material:"extratrims:breeze", item:"minecraft:breeze_rod"}

# Brick
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:brick"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:brick run return run \
function extratrims:change_trim_material/final {material:"extratrims:brick", item:"minecraft:brick"}

# Cake
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:cake"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:cake run return run \
function extratrims:change_trim_material/final {material:"extratrims:cake", item:"minecraft:cake"}

# Charcoal
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:charcoal"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:charcoal run return run \
function extratrims:change_trim_material/final {material:"extratrims:charcoal", item:"minecraft:charcoal"}

# Chorus
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:chorus"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:popped_chorus_fruit run return run \
function extratrims:change_trim_material/final {material:"extratrims:chorus", item:"minecraft:popped_chorus_fruit"}

# Clay
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:clay"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:clay_ball run return run \
function extratrims:change_trim_material/final {material:"extratrims:clay", item:"minecraft:clay_ball"}

# Coal
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:coal"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:coal run return run \
function extratrims:change_trim_material/final {material:"extratrims:coal", item:"minecraft:coal"}

# Cookie
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:cookie"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:cookie run return run \
function extratrims:change_trim_material/final {material:"extratrims:cookie", item:"minecraft:cookie"}

# Core
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:core"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:heavy_core run return run \
function extratrims:change_trim_material/final {material:"extratrims:core", item:"minecraft:heavy_core"}

# Creeper
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:creeper"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:creeper_head run return run \
function extratrims:change_trim_material/final {material:"extratrims:creeper", item:"minecraft:creeper_head"}

# Dragon
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:dragon"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:dragon_breath run return run \
function extratrims:change_trim_material/final {material:"extratrims:dragon", item:"minecraft:dragon_breath"}

# Dripstone
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:dripstone"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:pointed_dripstone run return run \
function extratrims:change_trim_material/final {material:"extratrims:dripstone", item:"minecraft:pointed_dripstone"}

# Echo
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:echo"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:echo_shard run return run \
function extratrims:change_trim_material/final {material:"extratrims:echo", item:"minecraft:echo_shard"}

# End Crystal
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:end_crystal"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:end_crystal run return run \
function extratrims:change_trim_material/final {material:"extratrims:end_crystal", item:"minecraft:end_crystal"}

# Ender Eye
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:ender_eye"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:ender_eye run return run \
function extratrims:change_trim_material/final {material:"extratrims:ender_eye", item:"minecraft:ender_eye"}

# Ender Pearl
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:ender_pearl"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:ender_pearl run return run \
function extratrims:change_trim_material/final {material:"extratrims:ender_pearl", item:"minecraft:ender_pearl"}

# Experience
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:experience"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:experience_bottle run return run \
function extratrims:change_trim_material/final {material:"extratrims:experience", item:"minecraft:experience_bottle"}

# Flesh
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:flesh"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:rotten_flesh run return run \
function extratrims:change_trim_material/final {material:"extratrims:flesh", item:"minecraft:rotten_flesh"}

# Glistering Melon
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:glistering_melon"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:glistering_melon_slice run return run \
function extratrims:change_trim_material/final {material:"extratrims:glistering_melon", item:"minecraft:glistering_melon_slice"}

# Glowstone
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:glowstone"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:glowstone_dust run return run \
function extratrims:change_trim_material/final {material:"extratrims:glowstone", item:"minecraft:glowstone_dust"}

# Gunpowder
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:gunpowder"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:gunpowder run return run \
function extratrims:change_trim_material/final {material:"extratrims:gunpowder", item:"minecraft:gunpowder"}

# Heart of the Sea
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:heart_of_the_sea"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:heart_of_the_sea run return run \
function extratrims:change_trim_material/final {material:"extratrims:heart_of_the_sea", item:"minecraft:heart_of_the_sea"}

# Honeycomb
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:honeycomb"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:honeycomb run return run \
function extratrims:change_trim_material/final {material:"extratrims:honeycomb", item:"minecraft:honeycomb"}

# Leather
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:leather"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:leather run return run \
function extratrims:change_trim_material/final {material:"extratrims:leather", item:"minecraft:leather"}

# Magma
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:magma"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:magma_cream run return run \
function extratrims:change_trim_material/final {material:"extratrims:magma", item:"minecraft:magma_cream"}

# Melon
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:melon"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:melon_slice run return run \
function extratrims:change_trim_material/final {material:"extratrims:melon", item:"minecraft:melon_slice"}

# Membrane
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:membrane"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:phantom_membrane run return run \
function extratrims:change_trim_material/final {material:"extratrims:membrane", item:"minecraft:phantom_membrane"}

# Nautilus
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:nautilus"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:nautilus_shell run return run \
function extratrims:change_trim_material/final {material:"extratrims:nautilus", item:"minecraft:nautilus_shell"}

# Nether Brick
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:nether_brick"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:nether_brick run return run \
function extratrims:change_trim_material/final {material:"extratrims:nether_brick", item:"minecraft:nether_brick"}

# Netherite Scrap
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:netherite_scrap"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:netherite_scrap run return run \
function extratrims:change_trim_material/final {material:"extratrims:netherite_scrap", item:"minecraft:netherite_scrap"}

# Ominous
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:ominous"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:ominous_bottle run return run \
function extratrims:change_trim_material/final {material:"extratrims:ominous", item:"minecraft:ominous_bottle"}

# Prismarine
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:prismarine"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:prismarine_crystals run return run \
function extratrims:change_trim_material/final {material:"extratrims:prismarine", item:"minecraft:prismarine_crystals"}

# Pumpkin Pie
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:pumpkin_pie"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:pumpkin_pie run return run \
function extratrims:change_trim_material/final {material:"extratrims:pumpkin_pie", item:"minecraft:pumpkin_pie"}

# Rabbit
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:rabbit"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:rabbit_hide run return run \
function extratrims:change_trim_material/final {material:"extratrims:rabbit", item:"minecraft:rabbit_hide"}

# Rainbow
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:rainbow"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:tinted_glass run return run \
function extratrims:change_trim_material/final {material:"extratrims:rainbow", item:"minecraft:tinted_glass"}

# Raw Copper
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:raw_copper"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:raw_copper run return run \
function extratrims:change_trim_material/final {material:"extratrims:raw_copper", item:"minecraft:raw_copper"}

# Raw Gold
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:raw_gold"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:raw_gold run return run \
function extratrims:change_trim_material/final {material:"extratrims:raw_gold", item:"minecraft:raw_gold"}

# Raw Iron
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:raw_iron"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:raw_iron run return run \
function extratrims:change_trim_material/final {material:"extratrims:raw_iron", item:"minecraft:raw_iron"}

# Shulker
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:shulker"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:shulker_shell run return run \
function extratrims:change_trim_material/final {material:"extratrims:shulker", item:"minecraft:shulker_shell"}

# Slime
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:slime"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:slime_ball run return run \
function extratrims:change_trim_material/final {material:"extratrims:slime", item:"minecraft:slime_ball"}

# Sniffer
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:sniffer"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:sniffer_egg run return run \
function extratrims:change_trim_material/final {material:"extratrims:sniffer", item:"minecraft:sniffer_egg"}

# Snow
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:snow"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:powder_snow_bucket run return run \
function extratrims:change_trim_material/final {material:"extratrims:snow", item:"minecraft:powder_snow_bucket"}

# Spider
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:spider"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:fermented_spider_eye run return run \
function extratrims:change_trim_material/final {material:"extratrims:spider", item:"minecraft:fermented_spider_eye"}

# Star
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:star"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:nether_star run return run \
function extratrims:change_trim_material/final {material:"extratrims:star", item:"minecraft:nether_star"}

# Sugar
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:sugar"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:sugar run return run \
function extratrims:change_trim_material/final {material:"extratrims:sugar", item:"minecraft:sugar"}

# TNT
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:tnt"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:tnt run return run \
function extratrims:change_trim_material/final {material:"extratrims:tnt", item:"minecraft:tnt"}

# Toast
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:toast"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:rabbit_foot run return run \
function extratrims:change_trim_material/final {material:"extratrims:toast", item:"minecraft:rabbit_foot"}

# Turtle
execute unless items entity @s container.0 *[minecraft:trim~{material:"extratrims:turtle"}] \
if items entity @n[type=minecraft:item, distance=.01...5] container.0 minecraft:turtle_scute run \
function extratrims:change_trim_material/final {material:"extratrims:turtle", item:"minecraft:turtle_scute"}