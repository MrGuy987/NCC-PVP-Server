execute at @s if entity @n[type=#tatevancements:dungeon_mobs, distance=..10] unless data entity @n[type=#tatevancements:dungeon_mobs] NoAI \
run return run advancement grant @s only tatevancements:apply_thematic_trims cage
advancement revoke @s only tatevancements:apply_thematic_trim_check/cage