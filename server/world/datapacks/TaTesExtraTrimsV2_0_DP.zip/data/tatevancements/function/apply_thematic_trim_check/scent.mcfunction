execute at @s if entity @n[type=minecraft:sniffer, distance=..10] unless data entity @n[type=minecraft:sniffer] NoAI \
run return run advancement grant @s only tatevancements:apply_thematic_trims scent
advancement revoke @s only tatevancements:apply_thematic_trim_check/scent