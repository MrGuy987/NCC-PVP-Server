execute at @s if entity @n[type=#tatevancements:skeletons, distance=..10] unless data entity @n[type=#tatevancements:skeletons] NoAI \
run return run advancement grant @s only tatevancements:apply_thematic_trims bone
advancement revoke @s only tatevancements:apply_thematic_trim_check/bone