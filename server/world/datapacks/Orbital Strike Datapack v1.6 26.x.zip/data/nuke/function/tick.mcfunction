execute as @a if score @s use_rod matches 1.. run function nuke:pull_activate/tag
scoreboard players set @a use_rod 0
execute as @a unless items entity @s weapon.mainhand fishing_rod run function nuke:pull_activate/remove_tag

execute as @a[tag=shot] run function nuke:pull_activate/pull/pull

execute as @e[type=block_display,tag=stabshot] run function nuke:orbital_strike_cannon/activate_shots/stab
execute as @e[type=block_display,tag=nukeshot] run function nuke:orbital_strike_cannon/activate_shots/nuke
execute as @e[type=block_display,tag=wolfshot] run function nuke:orbital_strike_cannon/activate_shots/wolf with storage nuke:uuid
execute as @e[type=block_display,tag=arrowshot] run function nuke:orbital_strike_cannon/activate_shots/arrow
execute as @e[type=block_display,tag=withershot] run function nuke:orbital_strike_cannon/activate_shots/wither

#pearl stasis
execute as @a[scores={x=1..}] run function nuke:orbital_strike_cannon/pearl_stasis/pearl_stasis_x
execute as @a[scores={y=1..}] run function nuke:orbital_strike_cannon/pearl_stasis/pearl_stasis_y
execute as @a[scores={z=1..}] run function nuke:orbital_strike_cannon/pearl_stasis/pearl_stasis_z
execute as @a[scores={x=..-1}] run function nuke:orbital_strike_cannon/pearl_stasis/pearl_stasis_x
execute as @a[scores={y=..-1}] run function nuke:orbital_strike_cannon/pearl_stasis/pearl_stasis_y
execute as @a[scores={z=..-1}] run function nuke:orbital_strike_cannon/pearl_stasis/pearl_stasis_z
execute as @e[type=marker,tag=stasis] at @s unless entity @n[type=ender_pearl,distance=..6] run kill @s