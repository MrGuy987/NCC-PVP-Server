execute as @s store result storage nuke:uuid UUID int 1 run data get entity @s UUID[0] 1
execute as @s store result storage nuke:uuid UUID1 int 1 run data get entity @s UUID[0] 1
execute as @s store result storage nuke:uuid UUID2 int 1 run data get entity @s UUID[1] 1
execute as @s store result storage nuke:uuid UUID3 int 1 run data get entity @s UUID[2] 1
execute as @s store result storage nuke:uuid UUID4 int 1 run data get entity @s UUID[3] 1
function nuke:orbital_strike_cannon/pearl_stasis/set_coords/pearl_stasis_x