give @s fishing_rod[custom_data={nukeshot:1b},custom_name={"italic":true,"text":"nukeshot"},rarity="rare",damage=63] 1
give @s fishing_rod[custom_data={stabshot:1b},custom_name={"italic":true,"text":"stabshot"},rarity="rare",damage=63] 1
give @s fishing_rod[custom_data={wolfshot:1b},custom_name={"italic":true,"text":"wolfshot"},rarity="rare",damage=63] 1
give @s fishing_rod[custom_data={arrowshot:1b},custom_name={"italic":true,"text":"arrowshot"},rarity="rare",damage=63] 1
give @s fishing_rod[custom_data={withershot:1b},custom_name={"italic":true,"text":"withershot"},rarity="rare",damage=63] 1