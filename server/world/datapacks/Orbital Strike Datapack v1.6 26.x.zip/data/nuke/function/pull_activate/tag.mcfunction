execute as @a store result storage nuke:uuid UUID int 1 run data get entity @s UUID[0] 1
execute as @a store result storage nuke:uuid UUID1 int 1 run data get entity @s UUID[0] 1
execute as @a store result storage nuke:uuid UUID2 int 1 run data get entity @s UUID[1] 1
execute as @a store result storage nuke:uuid UUID3 int 1 run data get entity @s UUID[2] 1
execute as @a store result storage nuke:uuid UUID4 int 1 run data get entity @s UUID[3] 1
execute at @s run function nuke:pull_activate/add_tag with storage nuke:uuid