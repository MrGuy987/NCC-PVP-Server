$execute if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] unless entity @e[type=fishing_bobber,tag=arrowshot,tag=$(UUID)] run function nuke:orbital_strike_cannon/use_rod
