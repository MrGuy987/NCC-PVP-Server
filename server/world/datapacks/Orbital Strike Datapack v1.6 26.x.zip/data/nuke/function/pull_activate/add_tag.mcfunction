execute if items entity @s weapon.mainhand fishing_rod[custom_data={stabshot:1b}] run tag @s add stabshot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={stabshot:1b}] run tag @s add shot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={stabshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add stabshot
$execute if items entity @s weapon.mainhand fishing_rod[custom_data={stabshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add $(UUID)
execute if items entity @s weapon.mainhand fishing_rod[custom_data={stabshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add bob

execute if items entity @s weapon.mainhand fishing_rod[custom_data={nukeshot:1b}] run tag @s add nukeshot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={nukeshot:1b}] run tag @s add shot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={nukeshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add nukeshot
$execute if items entity @s weapon.mainhand fishing_rod[custom_data={nukeshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add $(UUID)
execute if items entity @s weapon.mainhand fishing_rod[custom_data={nukeshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add bob

execute if items entity @s weapon.mainhand fishing_rod[custom_data={wolfshot:1b}] run tag @s add wolfshot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={wolfshot:1b}] run tag @s add shot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={wolfshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add wolfshot
$execute if items entity @s weapon.mainhand fishing_rod[custom_data={wolfshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add $(UUID)
execute if items entity @s weapon.mainhand fishing_rod[custom_data={wolfshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add bob

execute if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] run tag @s add arrowshot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] run tag @s add shot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add arrowshot
$execute if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add $(UUID)
execute if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add bob

execute if items entity @s weapon.mainhand fishing_rod[custom_data={withershot:1b}] run tag @s add withershot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={withershot:1b}] run tag @s add shot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={withershot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add withershot
$execute if items entity @s weapon.mainhand fishing_rod[custom_data={withershot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add $(UUID)
execute if items entity @s weapon.mainhand fishing_rod[custom_data={withershot:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add bob

execute if items entity @s weapon.mainhand fishing_rod[custom_data={pearl_stasis:1b}] run tag @s add pearl_stasis
execute if items entity @s weapon.mainhand fishing_rod[custom_data={pearl_stasis:1b}] run tag @s add shot
execute if items entity @s weapon.mainhand fishing_rod[custom_data={pearl_stasis:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add pearl_stasis
$execute if items entity @s weapon.mainhand fishing_rod[custom_data={pearl_stasis:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add $(UUID)
execute if items entity @s weapon.mainhand fishing_rod[custom_data={pearl_stasis:1b}] run tag @n[type=fishing_bobber,distance=..5,tag=!bob] add bob