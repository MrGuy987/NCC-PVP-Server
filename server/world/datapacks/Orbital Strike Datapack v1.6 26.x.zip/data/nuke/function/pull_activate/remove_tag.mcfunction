tag @s remove nukeshot
tag @s remove stabshot
tag @s remove wolfshot
tag @s remove arrowshot
tag @s remove withershot
tag @s remove pearl_stasis
tag @s remove shot