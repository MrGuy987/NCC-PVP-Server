execute as @a store result storage nuke:uuid UUID int 1 run data get entity @s UUID[0] 1
execute as @a store result storage nuke:uuid UUID1 int 1 run data get entity @s UUID[0] 1
execute as @a store result storage nuke:uuid UUID2 int 1 run data get entity @s UUID[1] 1
execute as @a store result storage nuke:uuid UUID3 int 1 run data get entity @s UUID[2] 1
execute as @a store result storage nuke:uuid UUID4 int 1 run data get entity @s UUID[3] 1

execute as @s[tag=nukeshot] at @s run function nuke:pull_activate/pull/nuke with storage nuke:uuid
execute as @s[tag=stabshot] at @s run function nuke:pull_activate/pull/stab with storage nuke:uuid
execute as @s[tag=wolfshot] at @s run function nuke:pull_activate/pull/wolf with storage nuke:uuid
execute as @s[tag=arrowshot] at @s run function nuke:pull_activate/pull/arrow with storage nuke:uuid
execute as @s[tag=withershot] at @s run function nuke:pull_activate/pull/wither with storage nuke:uuid
execute as @s[tag=pearl_stasis] at @s run function nuke:pull_activate/pull/pearl_stasis with storage nuke:uuid
