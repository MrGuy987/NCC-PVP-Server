execute unless block ~ ~ ~ air run summon tnt ~ ~2 ~ {fuse:1}
execute unless block ~ ~ ~ water unless block ~ ~ ~ bedrock positioned ~ ~-1 ~ run function nuke:orbital_strike_cannon/stabshot

execute if block ~ ~ ~ water if block ~ ~-1 ~ water unless block ~ ~ ~ bedrock positioned ~ ~-1 ~ run function nuke:orbital_strike_cannon/stabshot