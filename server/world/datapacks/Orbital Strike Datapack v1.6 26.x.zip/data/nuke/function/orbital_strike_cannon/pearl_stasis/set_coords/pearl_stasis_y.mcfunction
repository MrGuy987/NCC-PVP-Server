tellraw @s {text:"To set the Y coord, run \"/trigger y set <y coord>\"",color:"yellow",click_event:{action:"suggest_command",command:"/trigger y set "},hover_event:{action:"show_text",value:[{text:"/trigger y set",color:"white"}]}}
tellraw @s {text:"The Y coord must be a value greater or lower than 0",color:"gold"}
playsound entity.experience_orb.pickup ui @s ~ ~ ~ 10 .9
scoreboard players enable @s y
