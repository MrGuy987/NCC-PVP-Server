# HIT BLOCK
execute unless block ~ ~ ~ air if predicate nuke:under_ground run summon block_display ~ 80 ~ {Tags:["nukeshot"]}
execute unless block ~ ~ ~ air unless predicate nuke:under_ground run summon block_display ~ ~20 ~ {Tags:["nukeshot"]}
execute unless block ~ ~ ~ air run return 0

# MAX RANGE
execute if score @s raycast_limit matches 300.. if predicate nuke:under_ground run summon block_display ~ 80 ~ {Tags:["nukeshot"]}
execute if score @s raycast_limit matches 300.. unless predicate nuke:under_ground run summon block_display ~ ~20 ~ {Tags:["nukeshot"]}
execute if score @s raycast_limit matches 300.. run return 0

# CONTINUE
scoreboard players add @s raycast_limit 1
execute positioned ^ ^ ^0.5 run function nuke:orbital_strike_cannon/raycast/nukeshot/hit_check
