$execute at @e[type=marker,tag=$(UUID)] run setblock ~ ~ ~ oak_trapdoor[open=false]
$execute positioned $(X) $(Y) $(Z) run forceload remove ~5 ~5 ~-5 ~-5
$execute as @e[type=marker,tag=$(UUID)] run kill @s
