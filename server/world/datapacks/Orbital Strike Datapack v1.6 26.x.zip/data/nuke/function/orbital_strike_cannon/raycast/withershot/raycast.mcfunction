execute positioned ^ ^ ^.8 run function nuke:orbital_strike_cannon/raycast/withershot/hit_check
