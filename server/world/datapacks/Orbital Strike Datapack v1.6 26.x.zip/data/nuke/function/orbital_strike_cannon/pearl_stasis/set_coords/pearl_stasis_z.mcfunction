tellraw @s {text:"To set the Z coord, run \"/trigger z set <z coord>\"",color:"yellow",click_event:{action:"suggest_command",command:"/trigger z set "},hover_event:{action:"show_text",value:[{text:"/trigger z set",color:"white"}]}}
tellraw @s {text:"The Z coord must be a value greater or lower than 0",color:"gold"}
playsound entity.experience_orb.pickup ui @s ~ ~ ~ 10 .9
scoreboard players enable @s z
