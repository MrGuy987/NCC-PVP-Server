execute store result storage nuke:uuid Z int 1 run scoreboard players get @s z
scoreboard players reset @s z
function nuke:orbital_strike_cannon/pearl_stasis/pearl_stasis_finish with storage nuke:uuid