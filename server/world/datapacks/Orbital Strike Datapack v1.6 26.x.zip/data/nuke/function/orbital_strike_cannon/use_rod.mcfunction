execute store result storage nuke:uuid UUID int 1 run data get entity @s UUID[0] 1
execute store result storage nuke:uuid UUID1 int 1 run data get entity @s UUID[0] 1
execute store result storage nuke:uuid UUID2 int 1 run data get entity @s UUID[1] 1
execute store result storage nuke:uuid UUID3 int 1 run data get entity @s UUID[2] 1
execute store result storage nuke:uuid UUID4 int 1 run data get entity @s UUID[3] 1
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod run scoreboard players reset @s raycast_limit

execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={stabshot:1b}] run playsound item.shield.break player @a[distance=..10] ~ ~ ~ 30 1
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={nukeshot:1b}] run playsound item.shield.break player @a[distance=..10] ~ ~ ~ 30 1
execute if items entity @s weapon.mainhand fishing_rod[custom_data={wolfshot:1b}] run playsound item.shield.break player @a[distance=..10] ~ ~ ~ 30 1
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] run playsound item.shield.break player @a[distance=..10] ~ ~ ~ 30 1
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={withershot:1b}] run playsound item.shield.break player @a[distance=..10] ~ ~ ~ 30 1

execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={stabshot:1b}] anchored eyes run function nuke:orbital_strike_cannon/raycast/stabshot/raycast
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={nukeshot:1b}] anchored eyes run function nuke:orbital_strike_cannon/raycast/nukeshot/raycast
execute if items entity @s weapon.mainhand fishing_rod[custom_data={wolfshot:1b}] anchored eyes run function nuke:orbital_strike_cannon/raycast/wolfshot/hit with storage nuke:uuid
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={pearl_stasis:1b}] run function nuke:orbital_strike_cannon/pearl_stasis with storage nuke:uuid
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] anchored eyes run function nuke:orbital_strike_cannon/raycast/arrowshot/raycast
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={withershot:1b}] anchored eyes run function nuke:orbital_strike_cannon/raycast/withershot/raycast


execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={stabshot:1b}] run item replace entity @s weapon.mainhand with air
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={nukeshot:1b}] run item replace entity @s weapon.mainhand with air
execute if items entity @s weapon.mainhand fishing_rod[custom_data={wolfshot:1b}] run item replace entity @s weapon.mainhand with air
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={arrowshot:1b}] run item replace entity @s weapon.mainhand with air
execute if dimension overworld if items entity @s weapon.mainhand fishing_rod[custom_data={withershot:1b}] run item replace entity @s weapon.mainhand with air

tag @s remove nukeshot
tag @s remove stabshot
tag @s remove wolfshot
tag @s remove arrowshot
tag @s remove withershot
tag @s remove pearl_stasis
tag @s remove shot
