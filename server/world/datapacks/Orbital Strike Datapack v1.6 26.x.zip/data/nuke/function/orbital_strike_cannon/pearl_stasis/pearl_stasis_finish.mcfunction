$execute positioned $(X) $(Y) $(Z) run forceload add ~5 ~5 ~-5 ~-5
$execute positioned $(X) $(Y) $(Z) run setblock ~1 ~-1 ~ cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~-1 ~-1 ~ cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-1 ~1 cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-1 ~-1 cobblestone

$execute positioned $(X) $(Y) $(Z) run setblock ~1 ~-2 ~ cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~-1 ~-2 ~ cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-2 ~1 cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-2 ~-1 cobblestone

$execute positioned $(X) $(Y) $(Z) run setblock ~1 ~-3 ~ cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~-1 ~-3 ~ cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-3 ~1 cobblestone
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-3 ~-1 cobblestone

$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-4 ~ soul_sand
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-3 ~ water
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-2 ~ water
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~-1 ~ water
$execute positioned $(X) $(Y) $(Z) run setblock ~ ~ ~1 oak_pressure_plate

$execute positioned $(X) $(Y) $(Z) run setblock ~ ~ ~ oak_trapdoor[open=true]

$execute positioned $(X) $(Y) $(Z) run summon ender_pearl ~ ~ ~ {Tags:["$(UUID)"]}
$execute positioned $(X) $(Y) $(Z) run summon ender_pearl ~ ~ ~ {Owner:[I;$(UUID1),$(UUID2),$(UUID3),$(UUID4)],Tags:["$(UUID)"]}
$execute positioned $(X) $(Y) $(Z) run summon marker ~ ~ ~ {Tags:["stasis","$(UUID)"]}
#$execute positioned $(X) $(Y) $(Z) as @e[type=ender_pearl,limit=1,tag=$(UUID)] run data modify entity @s Owner set from entity @e[tag=$(UUID),limit=1] UUID
$give @s fishing_rod[custom_data={pearl_stasis:1b},custom_name={"italic":true,"text":"$(X) $(Y) $(Z)"},rarity="rare"] 1
