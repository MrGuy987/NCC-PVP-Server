execute store result storage nuke:uuid X int 1 run scoreboard players get @s x
scoreboard players reset @s x
function nuke:orbital_strike_cannon/pearl_stasis/set_coords/pearl_stasis_y