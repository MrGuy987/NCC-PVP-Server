tellraw @s {text:"To set the X coord, run \"/trigger x set <x coord>\"",color:"yellow",click_event:{action:"suggest_command",command:"/trigger x set "},hover_event:{action:"show_text",value:[{text:"/trigger x set",color:"white"}]}}
tellraw @s {text:"The X coord must be a value greater or lower than 0",color:"gold"}
playsound entity.experience_orb.pickup ui @s ~ ~ ~ 10 .9
scoreboard players enable @s x
