execute as @e[type=block_display,tag=withershot] run scoreboard players add @s withershot_timer 1
execute as @e[type=block_display,tag=withershot,scores={withershot_timer=10..}] at @s run function nuke:orbital_strike_cannon/withershot
execute as @e[type=block_display,tag=withershot,scores={withershot_timer=10..}] run kill @s