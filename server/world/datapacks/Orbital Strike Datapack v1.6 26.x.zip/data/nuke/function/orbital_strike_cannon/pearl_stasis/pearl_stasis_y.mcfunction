execute store result storage nuke:uuid Y int 1 run scoreboard players get @s y
scoreboard players reset @s y
function nuke:orbital_strike_cannon/pearl_stasis/set_coords/pearl_stasis_z