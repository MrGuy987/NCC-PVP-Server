#Made By TheDuckInBlue
scoreboard objectives add use_rod minecraft.used:minecraft.fishing_rod
scoreboard objectives add raycast_limit dummy
scoreboard objectives add stabshot_timer dummy
scoreboard objectives add nukeshot_timer dummy
scoreboard objectives add wolfshot_timer dummy
scoreboard objectives add arrowshot_timer dummy
scoreboard objectives add withershot_timer dummy
scoreboard objectives add rod_delay dummy
scoreboard objectives add pearl_stasis_timer dummy
scoreboard objectives add x trigger
scoreboard objectives add y trigger
scoreboard objectives add z trigger

#
scoreboard objectives add player_uuid dummy

#
execute as @a store result storage nuke:uuid UUID int 1 run data get entity @s UUID[0] 1
execute as @a store result storage nuke:uuid UUID1 int 1 run data get entity @s UUID[0] 1
execute as @a store result storage nuke:uuid UUID2 int 1 run data get entity @s UUID[1] 1
execute as @a store result storage nuke:uuid UUID3 int 1 run data get entity @s UUID[2] 1
execute as @a store result storage nuke:uuid UUID4 int 1 run data get entity @s UUID[3] 1