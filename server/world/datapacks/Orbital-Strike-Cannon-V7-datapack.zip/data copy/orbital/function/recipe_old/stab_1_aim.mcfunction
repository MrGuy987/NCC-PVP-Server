clear @s minecraft:knowledge_book[custom_data={recipe_stab_1_aim_old:1b}]
execute if score craft_toggle_ craft_toggle_ matches 1 run give @s fishing_rod[custom_name='[{"text":"STAB POWER 1 (aim)","italic":false}]',damage=63,custom_data={stab_aim_1:1b}]
execute if score craft_toggle_ craft_toggle_ matches 0 run give @s minecraft:tnt 2
execute if score craft_toggle_ craft_toggle_ matches 0 run give @s minecraft:fishing_rod
execute if score craft_toggle_ craft_toggle_ matches 0 run give @s minecraft:redstone 2