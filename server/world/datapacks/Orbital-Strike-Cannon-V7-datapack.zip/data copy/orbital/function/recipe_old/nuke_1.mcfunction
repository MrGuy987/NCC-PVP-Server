clear @s minecraft:knowledge_book[custom_data={recipe_nuke_1_old:1b}]
execute if score craft_toggle_ craft_toggle_ matches 1 run give @s fishing_rod[custom_name='[{"text":"NUKE POWER 1","italic":false}]',damage=63,custom_data={nuke_1:1b}]
execute if score craft_toggle_ craft_toggle_ matches 0 run give @s minecraft:tnt 4
execute if score craft_toggle_ craft_toggle_ matches 0 run give @s minecraft:fishing_rod