execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_nuke_1_old:1b}] run function orbital:recipe_old/nuke_1
execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_nuke_1_aim_old:1b}] run function orbital:recipe_old/nuke_1_aim

execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_nuke_2_old:1b}] run function orbital:recipe_old/nuke_2
execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_nuke_2_aim_old:1b}] run function orbital:recipe_old/nuke_2_aim

execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_nuke_3_old:1b}] run function orbital:recipe_old/nuke_3
execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_nuke_3_aim_old:1b}] run function orbital:recipe_old/nuke_3_aim

execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_stab_1_old:1b}] run function orbital:recipe_old/stab_1
execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_stab_1_aim_old:1b}] run function orbital:recipe_old/stab_1_aim

execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_stab_2_old:1b}] run function orbital:recipe_old/stab_2
execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_stab_2_aim_old:1b}] run function orbital:recipe_old/stab_2_aim

execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_stab_3_old:1b}] run function orbital:recipe_old/stab_3
execute as @a if items entity @s container.* minecraft:knowledge_book[custom_data={recipe_stab_3_aim_old:1b}] run function orbital:recipe_old/stab_3_aim

scoreboard players set test test_recipe_func 1