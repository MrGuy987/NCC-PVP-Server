execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_1_old
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_1_aim_old

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_2_old
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_2_aim_old

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_3_old
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_3_aim_old

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_1_old
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_1_aim_old

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_2_old
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_2_aim_old

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_3_old
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_3_aim_old