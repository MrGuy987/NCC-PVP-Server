execute at @s run function orbital:stab_power_1
item replace entity @s weapon.mainhand with air
execute at @s run playsound minecraft:item.shield.break master @a ~ ~ ~