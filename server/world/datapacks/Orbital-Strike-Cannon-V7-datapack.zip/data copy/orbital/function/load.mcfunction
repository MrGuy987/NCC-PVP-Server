scoreboard objectives add toggle_message_ dummy
scoreboard objectives add craft_toggle_ dummy
scoreboard objectives add one dummy
execute unless score one one matches 1 run function orbital:one
scoreboard players set one one 1
execute if score toggle_message_ toggle_message_ matches 1 run tellraw @a ["",{"text":"Orbital Strike Cannon DataPack by ","color":"gold"},{"text":"Stepan1411","color":"red","clickEvent":{"action":"open_url","value":"https://modrinth.com/user/Stepan1411_Studio"}}," & ",{"text":"Shanahan","color":"red","clickEvent":{"action":"open_url","value":"https://modrinth.com/user/Shanahan_7"}}]
execute if score toggle_message_ toggle_message_ matches 1 if score craft_toggle_ craft_toggle_ matches 1 run tellraw @a ["",{"text":"Orbital Strike Cannon ","color":"gold"},{"text":"craft","underlined":true,"color":"gold"},{"text":":","color":"gold"}," ",{"text":"enebled","color":"green"}]
execute if score toggle_message_ toggle_message_ matches 1 if score craft_toggle_ craft_toggle_ matches 0 run tellraw @a ["",{"text":"Orbital Strike Cannon ","color":"gold"},{"text":"craft","underlined":true,"color":"gold"},{"text":":","color":"gold"}," ",{"text":"disbled","color":"red"}]
execute if score toggle_message_ toggle_message_ matches 1 run tellraw @a [{"text":"(you can disable this message using","italic":true,"color":"gold"},{"text":" ","color":"gold"},{"text":"/function orbital:settings/message_disable","bold":true,"color":"gold"},{"text":")","italic":true,"color":"gold"}]
function orbital:gr_1_21_11
function orbital:gr_1_21_6