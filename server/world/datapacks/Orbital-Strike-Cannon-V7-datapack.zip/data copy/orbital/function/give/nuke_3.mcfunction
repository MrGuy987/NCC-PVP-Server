function orbital:give_old/nuke_3
function orbital:give_new/nuke_3