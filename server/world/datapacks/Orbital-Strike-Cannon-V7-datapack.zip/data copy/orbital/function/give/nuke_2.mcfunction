function orbital:give_old/nuke_2
function orbital:give_new/nuke_2