function orbital:give_old/nuke_1
function orbital:give_new/nuke_1