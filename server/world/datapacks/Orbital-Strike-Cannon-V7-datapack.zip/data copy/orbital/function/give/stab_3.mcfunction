function orbital:give_old/stab_3
function orbital:give_new/stab_3