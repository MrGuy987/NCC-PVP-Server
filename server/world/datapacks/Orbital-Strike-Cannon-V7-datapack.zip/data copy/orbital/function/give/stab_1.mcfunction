function orbital:give_old/stab_1
function orbital:give_new/stab_1