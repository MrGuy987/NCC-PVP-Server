function orbital:give_old/stab_2
function orbital:give_new/stab_2