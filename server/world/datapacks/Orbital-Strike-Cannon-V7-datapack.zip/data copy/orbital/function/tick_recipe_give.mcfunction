# Recipe give

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_1
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_1_aim

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_2
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_2_aim

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_3
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:nuke_3_aim

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_1
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_1_aim

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_2
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_2_aim

execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_3
execute if score craft_toggle_ craft_toggle_ matches 1 run recipe give @a orbital:stab_3_aim