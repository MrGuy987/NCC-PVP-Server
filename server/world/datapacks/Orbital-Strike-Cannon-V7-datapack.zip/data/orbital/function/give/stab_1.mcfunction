function orbital:give_messages/stab_1
function orbital:give_new/stab_1