function orbital:give_messages/nuke_1
function orbital:give_new/nuke_1