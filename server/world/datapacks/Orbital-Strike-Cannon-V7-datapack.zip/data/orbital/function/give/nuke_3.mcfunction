function orbital:give_messages/nuke_3
function orbital:give_new/nuke_3