function orbital:give_messages/stab_2
function orbital:give_new/stab_2