function orbital:give_messages/nuke_2
function orbital:give_new/nuke_2