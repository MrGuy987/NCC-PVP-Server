### Kill arrow
kill @s